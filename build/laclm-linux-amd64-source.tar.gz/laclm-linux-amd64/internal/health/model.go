package health

/* health response */
type HealthResponse struct {
	Status string `json:"status"`
}
