package session

import (
	"context"
	"time"

	"github.com/gorilla/websocket"
)

/* ==== User Sessions ==== */

/* send list of all sesssions */
func (m *Manager) sendListofAllSessions(conn *websocket.Conn, limit int) error {
	ctx := context.Background()

	/* cursor for navigating Redis Scan */
	var cursor uint64

	/* store all sessions keys here */
	var sessionKeys []string

	/* get all the session keys in the whole Redis database */
	for {
		keys, nextCursor, err := m.redis.Scan(ctx, cursor, "session:*", 100).Result()
		if err != nil {
			message := StreamMessage{
				Type: "sessions_list",
				Data: map[string]interface{}{
					"exists":     false,
				},
				Timestamp: time.Now(),
			}
			return conn.WriteJSON(message)
		}

		sessionKeys = append(sessionKeys, keys...)
		cursor = nextCursor
		if cursor == 0 {
			break
		}
	}

	/* will contain data about all the sessions */
	var sessions []SessionStreamData

	/* get data about all the session from Redis */
	for _, key := range sessionKeys {

		/* get session data from Redis */
		sessionData, err := m.redis.HGetAll(ctx, key).Result()
		if err != nil || len(sessionData) == 0 {
			continue
		}

		/* deserialize into SessionStreamData */
		session := convertRedisHashToSession(sessionData)

		sessions = append(sessions, session)
	}

	/* build the message with all sessions data */
	message := StreamMessage{
		Type: "sessions_list",
		Data: map[string]interface{}{
			"sessions":		sessions,	
		},
		Timestamp: time.Now(),
	}

	return conn.WriteJSON(message)
}
